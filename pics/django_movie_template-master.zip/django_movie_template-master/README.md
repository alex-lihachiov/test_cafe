<p align="center">
    <a href="https://djangochannel.com" target="_blank" rel="noopener noreferrer">
        <img width="100" src="logo.png" title="djangoschool">
    </a>
</p>

<h2 align="center">Django Movie - шаблон html</h2>

[Сайт](https://djangochannel.com)

[GitHub](https://github.com/DJWOMS/django_movie)

[YouTube](https://www.youtube.com/channel/UC_hPYclmFCIENpMUHpPY8FQ?view_as=subscriber)

Шаблон кинобиблиотеки на Django 3.
